"""
ШАГ 4 — Демо-приложение (Gradio).

Показывает: исходное изображение, предсказанный класс, уверенность (топ-k),
краткую статистику сессии (число запросов, средняя уверенность, среднее время,
распределение классов). История запусков пишется в runs/demo_history.jsonl.

Запуск:
  python demo/app.py
  python demo/app.py --model efficientnet_b0   # принудительно выбрать модель
"""
from __future__ import annotations
import argparse
import json
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

import gradio as gr

# ── фикс известного бага gradio 4.44: get_type получает bool-схему ────────
import gradio_client.utils as _gcu
_orig_get_type = _gcu.get_type
_orig_js = _gcu._json_schema_to_python_type
def _safe_get_type(schema):
    if not isinstance(schema, dict):
        return "Any"
    return _orig_get_type(schema)
def _safe_js(schema, defs=None):
    if not isinstance(schema, dict):
        return "Any"
    return _orig_js(schema, defs)
_gcu.get_type = _safe_get_type
_gcu._json_schema_to_python_type = _safe_js

import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.inference import Predictor
from src.utils.config import load_config

MODELS_DIR = ROOT / "models"
HISTORY = ROOT / "runs" / "demo_history.jsonl"

_TASK = load_config("configs/data.yaml").get("task", {})
RECS = _TASK.get("recommendations", {})
TITLE = _TASK.get("title", "Классификатор изображений")
DESC = _TASK.get("description", "")

_PRED_CACHE: dict[str, Predictor] = {}
_SESSION: list[dict] = []


def available_models() -> list[str]:
    return sorted(p.stem for p in MODELS_DIR.glob("*.pt"))


def default_model() -> str:
    bm = ROOT / "runs" / "best_model.json"
    if bm.exists():
        data = json.loads(bm.read_text())
        key = data.get("recommended_model") or data.get("best_model")
        if key and (MODELS_DIR / f"{key}.pt").exists():
            return key
    keys = available_models()
    return keys[0] if keys else ""


def get_predictor(key: str) -> Predictor:
    if key not in _PRED_CACHE:
        _PRED_CACHE[key] = Predictor(MODELS_DIR / f"{key}.pt")
    return _PRED_CACHE[key]


def log_history(rec: dict):
    HISTORY.parent.mkdir(parents=True, exist_ok=True)
    with open(HISTORY, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def session_stats_md() -> str:
    if not _SESSION:
        return "_Пока нет предсказаний в этой сессии._"
    n = len(_SESSION)
    avg_conf = sum(r["confidence"] for r in _SESSION) / n
    avg_ms = sum(r["inference_ms"] for r in _SESSION) / n
    dist = Counter(r["label"] for r in _SESSION)
    top = "  \n".join(f"- {k}: {v}" for k, v in dist.most_common(5))
    return (f"**Запросов:** {n}  \n"
            f"**Средняя уверенность:** {avg_conf:.1%}  \n"
            f"**Среднее время инференса:** {avg_ms:.1f} мс ({1000/avg_ms:.1f} FPS)  \n"
            f"**Распределение предсказаний (топ-5):**  \n{top}")


def predict(image, model_key):
    if image is None:
        return {}, "Загрузите изображение единицы отхода.", session_stats_md()
    predictor = get_predictor(model_key)
    out = predictor.predict(image, topk=5)
    rec = {"time": datetime.now().isoformat(timespec="seconds"),
           "model": model_key, "label": out["label"],
           "confidence": out["confidence"], "inference_ms": out["inference_ms"]}
    _SESSION.append(rec)
    log_history(rec)

    label_conf = {cls: prob for cls, prob in out["topk"]}
    advice = RECS.get(out["label"], "—")
    low = out["confidence"] < 0.5
    verdict = (f"### ♻️ {out['label'].upper()}"
               f"{'  ⚠️ низкая уверенность' if low else ''}\n"
               f"**Уверенность:** {out['confidence']:.1%}  \n"
               f"**Модель:** {model_key}  \n"
               f"**Время инференса:** {out['inference_ms']:.1f} мс\n\n"
               f"**🗑️ Рекомендация по сортировке:**  \n{advice}"
               + ("\n\n_Уверенность низкая — рекомендуется ручная проверка._" if low else ""))
    return label_conf, verdict, session_stats_md()


def build_ui(init_model: str):
    with gr.Blocks(title=TITLE) as demo:
        gr.Markdown(f"# ♻️ {TITLE}\n{DESC}\n\n"
                    "Загрузите фото отхода — модель определит тип материала, покажет "
                    "уверенность и **рекомендацию по сортировке**. "
                    "Лучшая модель выбрана на ШАГЕ 3.")
        with gr.Row():
            with gr.Column():
                inp = gr.Image(type="pil", label="Изображение отхода", height=320)
                model_dd = gr.Dropdown(available_models(), value=init_model,
                                       label="Модель")
                btn = gr.Button("Распознать", variant="primary")
            with gr.Column():
                verdict = gr.Markdown(label="Результат")
                label = gr.Label(num_top_classes=5, label="Топ-5 классов (уверенность)")
        with gr.Accordion("📊 Статистика сессии", open=True):
            stats = gr.Markdown(session_stats_md())

        btn.click(predict, [inp, model_dd], [label, verdict, stats])
        inp.change(predict, [inp, model_dd], [label, verdict, stats])
    return demo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=None, help="ключ модели (по умолчанию — лучшая)")
    ap.add_argument("--share", action="store_true")
    ap.add_argument("--port", type=int, default=7860)
    args = ap.parse_args()

    if not available_models():
        raise SystemExit("Нет обученных моделей в models/. Сначала ШАГ 2 (train).")
    init_model = args.model or default_model()
    print(f"Лучшая/выбранная модель: {init_model}")
    # show_api=False обходит баг схемы gradio 4.44 ('const' in schema)
    build_ui(init_model).launch(server_name="127.0.0.1", server_port=args.port,
                                share=args.share, show_api=False, quiet=True)


if __name__ == "__main__":
    main()
