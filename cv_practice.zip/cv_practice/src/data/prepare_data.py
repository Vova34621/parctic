"""
ШАГ 1 — Подготовка данных для классификации листьев томата (PlantVillage).

Что делает скрипт (закрывает требования методички, разд. 3 и 6):
  1. Сканирует датасет в формате ImageFolder и фильтрует классы (Tomato*).
  2. Проверяет КАЖДОЕ изображение на открываемость (битые файлы отбрасываются).
  3. Контроль утечки данных:
       • удаляет байт-идентичные дубликаты (md5);
       • группирует перцептивные дубли (одинаковый pHash) и держит группу
         целиком в одном сплите — один и тот же лист не попадёт и в train, и в test.
  4. Делает СТРАТИФИЦИРОВАННЫЙ train/val/test split на уровне групп, seed фиксирован.
  5. Считает баланс классов по сплитам, строит график, считает собственные mean/std
     (на train, без утечки) для отчёта.
  6. Сохраняет:
       data/splits/manifest.csv      — единый split для ВСЕХ моделей
       data/splits/class_map.json    — соответствие класс <-> индекс
       data/splits/dataset_stats.json
       data/splits/class_distribution.png
       configs/norm_stats.json       — mean/std (свои + imagenet)

Запуск:
  python -m src.data.prepare_data --config configs/data.yaml
  python -m src.data.prepare_data --max-per-class 200   # быстрый смоук-тест
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import random
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from tqdm import tqdm
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

try:
    import imagehash  # type: ignore
except ImportError:  # pragma: no cover
    imagehash = None

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.utils.config import load_config, resolve_path, PROJECT_ROOT  # noqa: E402
from src.utils.seed import seed_everything  # noqa: E402

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


# ─────────────────────────── вспомогательное ────────────────────────────
def find_class_dirs(raw_dir: Path) -> list[Path]:
    """Найти папки-классы. Если внутри есть color/ (PlantVillage) — спускаемся в неё."""
    if not raw_dir.exists():
        raise SystemExit(f"[ОШИБКА] Нет папки с данными: {raw_dir}\n"
                         f"Скачай датасет и распакуй в data/raw/ (см. README, ШАГ 1).")
    # частый случай: data/raw/<...>/color/<классы>
    for cand in [raw_dir, *raw_dir.rglob("color")]:
        subdirs = [d for d in cand.iterdir() if d.is_dir()] if cand.is_dir() else []
        if any(any(f.suffix.lower() in IMG_EXTS for f in d.iterdir() if f.is_file())
               for d in subdirs[:3] if d.is_dir()):
            return sorted(subdirs)
    # fallback: рекурсивно ищем папки, где лежат картинки
    cls = sorted({f.parent for f in raw_dir.rglob("*")
                  if f.is_file() and f.suffix.lower() in IMG_EXTS})
    if not cls:
        raise SystemExit(f"[ОШИБКА] В {raw_dir} не нашёл изображений.")
    return cls


def filter_classes(class_dirs: list[Path], cfg: dict) -> list[Path]:
    mode = cfg["class_filter"]["mode"]
    if mode == "prefix":
        pref = cfg["class_filter"]["prefix"]
        out = [d for d in class_dirs if d.name.startswith(pref)]
    elif mode == "list":
        wl = set(cfg["class_filter"]["list"])
        out = [d for d in class_dirs if d.name in wl]
    else:
        out = list(class_dirs)
    if not out:
        raise SystemExit(f"[ОШИБКА] Фильтр классов ничего не выбрал.\n"
                         f"Найденные классы: {[d.name for d in class_dirs]}")
    return out


def clean_label(name: str, regex: str | None) -> str:
    return re.sub(regex, "", name) if regex else name


def process_file(path: Path, phash_size: int):
    """Прочитать файл один раз: md5 + проверка целостности + pHash."""
    try:
        data = path.read_bytes()
        md5 = hashlib.md5(data).hexdigest()
        Image.open(io.BytesIO(data)).verify()           # целостность
        img = Image.open(io.BytesIO(data)).convert("L")  # заново — verify «портит» объект
        ph = str(imagehash.phash(img, hash_size=phash_size)) if imagehash else md5
        return md5, ph, None
    except Exception as e:
        return None, None, f"{type(e).__name__}: {e}"


# ──────────────────────────────── main ──────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="Подготовка данных (ШАГ 1)")
    ap.add_argument("--config", default="configs/data.yaml")
    ap.add_argument("--raw-dir", default=None, help="переопределить raw_dir из конфига")
    ap.add_argument("--max-per-class", type=int, default=None, help="подвыборка для смоук-теста")
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    seed = args.seed if args.seed is not None else cfg["seed"]
    seed_everything(seed)
    rng = random.Random(seed)

    if args.raw_dir:
        cfg["raw_dir"] = args.raw_dir
    if args.max_per_class is not None:
        cfg["max_per_class"] = args.max_per_class

    raw_dir = resolve_path(cfg["raw_dir"])
    phash_size = cfg["dedup"]["phash_size"]
    clean_re = cfg.get("label_clean_regex")

    print(f"\n{'='*64}\n  ШАГ 1: подготовка данных | seed={seed}\n{'='*64}")
    print(f"Источник: {raw_dir}")

    # 1) классы --------------------------------------------------------------
    class_dirs = filter_classes(find_class_dirs(raw_dir), cfg)
    display_names = sorted({clean_label(d.name, clean_re) for d in class_dirs})
    class_to_idx = {c: i for i, c in enumerate(display_names)}
    print(f"\nКлассов выбрано: {len(display_names)}")
    for d in class_dirs:
        n = sum(1 for f in d.iterdir() if f.suffix.lower() in IMG_EXTS)
        print(f"  {clean_label(d.name, clean_re):28s} <- {d.name:32s} {n:5d} файлов")

    # 2) собрать список файлов (+ опц. подвыборка) ---------------------------
    records = []  # (path, display_class)
    for d in class_dirs:
        files = sorted(f for f in d.iterdir() if f.suffix.lower() in IMG_EXTS)
        if cfg["max_per_class"]:
            files = files[:] if len(files) <= cfg["max_per_class"] else \
                rng.sample(files, cfg["max_per_class"])
        cls = clean_label(d.name, clean_re)
        records.extend((f, cls) for f in files)
    print(f"\nВсего файлов к обработке: {len(records)}")

    # 3) верификация + хэши --------------------------------------------------
    rows, corrupt = [], []
    for path, cls in tqdm(records, desc="Проверка/хэширование", unit="img"):
        md5, ph, err = process_file(path, phash_size)
        if err:
            corrupt.append((str(path), err))
            continue
        rows.append({"path": str(path), "class": cls, "md5": md5, "phash": ph})
    df = pd.DataFrame(rows)
    print(f"Битых/нечитаемых отброшено: {len(corrupt)}")

    # 4) дедупликация --------------------------------------------------------
    n_before = len(df)
    if cfg["dedup"]["drop_exact_md5"]:
        df = df.sort_values("path").drop_duplicates("md5", keep="first").reset_index(drop=True)
    n_md5_dropped = n_before - len(df)
    print(f"Точных (md5) дубликатов удалено: {n_md5_dropped}")

    # group_id: перцептивные дубли в пределах одного класса -> одна группа
    if cfg["dedup"]["phash_group"]:
        df["group_id"] = df["class"] + "::" + df["phash"]
    else:
        df["group_id"] = df.index.astype(str)
    n_groups = df["group_id"].nunique()
    print(f"Групп (после pHash): {n_groups}  |  near-дублей сжато: {len(df) - n_groups}")

    # 5) стратифицированный split на уровне групп ----------------------------
    tr, va = cfg["split"]["train"], cfg["split"]["val"]
    df["split"] = None
    for cls in display_names:
        sub = df[df["class"] == cls]
        groups = [(gid, g.index.tolist()) for gid, g in sub.groupby("group_id")]
        rng.shuffle(groups)
        total = len(sub)
        t_train, t_val = total * tr, total * (tr + va)
        cum = 0
        for gid, idxs in groups:
            split = "train" if cum < t_train else ("val" if cum < t_val else "test")
            df.loc[idxs, "split"] = split
            cum += len(idxs)

    df["label_idx"] = df["class"].map(class_to_idx)

    # 6) проверка анти-утечки: ни одна группа не пересекает сплиты -----------
    leak = df.groupby("group_id")["split"].nunique()
    assert (leak == 1).all(), "УТЕЧКА: группа дублей попала в разные сплиты!"
    print("Анти-утечка: OK (каждая группа дублей — в одном сплите)")

    # 7) баланс классов + график --------------------------------------------
    pivot = df.pivot_table(index="class", columns="split", values="path",
                           aggfunc="count", fill_value=0)
    pivot = pivot.reindex(columns=["train", "val", "test"], fill_value=0)
    print("\nРаспределение по классам и сплитам:")
    print(pivot.to_string())
    print(f"\nИТОГО  train={int(pivot['train'].sum())}  "
          f"val={int(pivot['val'].sum())}  test={int(pivot['test'].sum())}")

    dist_plot = resolve_path(cfg["dist_plot"])
    ax = pivot.plot(kind="bar", figsize=(12, 6), width=0.8)
    ax.set_title("Баланс классов по сплитам (Tomato leaf disease)")
    ax.set_ylabel("кол-во изображений")
    ax.set_xlabel("")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    plt.savefig(dist_plot, dpi=130)
    plt.close()

    # 8) собственные mean/std на train (для отчёта; без утечки) --------------
    train_paths = df[df["split"] == "train"]["path"].tolist()
    sample = train_paths if len(train_paths) <= cfg["norm_sample"] \
        else rng.sample(train_paths, cfg["norm_sample"])
    size = cfg["image_size"]
    s = np.zeros(3, np.float64); s2 = np.zeros(3, np.float64); npix = 0
    for p in tqdm(sample, desc="Расчёт mean/std (train)", unit="img"):
        a = np.asarray(Image.open(p).convert("RGB").resize((size, size)),
                       dtype=np.float64) / 255.0
        a = a.reshape(-1, 3)
        s += a.sum(0); s2 += (a ** 2).sum(0); npix += a.shape[0]
    ds_mean = (s / npix).tolist()
    ds_std = np.sqrt(np.clip(s2 / npix - (s / npix) ** 2, 1e-12, None)).tolist()
    print(f"\nDataset mean (train): {[round(x,4) for x in ds_mean]}")
    print(f"Dataset std  (train): {[round(x,4) for x in ds_std]}")

    # 9) сохранение артефактов ----------------------------------------------
    manifest_csv = resolve_path(cfg["manifest_csv"])
    df[["path", "class", "label_idx", "split", "group_id", "md5"]] \
        .sort_values(["split", "class", "path"]).to_csv(manifest_csv, index=False)

    with open(resolve_path(cfg["class_map_json"]), "w", encoding="utf-8") as f:
        json.dump({"classes": display_names,
                   "class_to_idx": class_to_idx,
                   "idx_to_class": {i: c for c, i in class_to_idx.items()}},
                  f, ensure_ascii=False, indent=2)

    with open(resolve_path(cfg["norm_stats_json"]), "w", encoding="utf-8") as f:
        json.dump({"used": cfg["normalize"],
                   "image_size": size,
                   "dataset": {"mean": ds_mean, "std": ds_std,
                               "sampled_images": len(sample)},
                   "imagenet": {"mean": IMAGENET_MEAN, "std": IMAGENET_STD}},
                  f, ensure_ascii=False, indent=2)

    stats = {
        "seed": seed,
        "raw_dir": str(raw_dir),
        "num_classes": len(display_names),
        "classes": display_names,
        "total_images": int(len(df)),
        "split_ratios": cfg["split"],
        "counts": {"train": int(pivot["train"].sum()),
                   "val": int(pivot["val"].sum()),
                   "test": int(pivot["test"].sum())},
        "per_class": pivot.astype(int).to_dict(orient="index"),
        "dropped": {"corrupt": len(corrupt), "md5_duplicates": int(n_md5_dropped)},
        "phash_groups": int(n_groups),
        "max_per_class": cfg["max_per_class"],
    }
    with open(resolve_path(cfg["stats_json"]), "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)

    if corrupt:
        with open(resolve_path("data/splits/corrupt_files.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(f"{p}\t{e}" for p, e in corrupt))

    print(f"\n{'='*64}\n  Готово. Артефакты:\n{'='*64}")
    for p in [manifest_csv, cfg["class_map_json"], cfg["stats_json"],
              cfg["norm_stats_json"], cfg["dist_plot"]]:
        print(f"  • {resolve_path(p).relative_to(PROJECT_ROOT)}")
    print("\nЭтот manifest.csv — ЕДИНЫЙ split для всех 5 моделей (ШАГ 2).")


if __name__ == "__main__":
    main()
