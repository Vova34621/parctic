"""
Единый Dataset/DataLoader для всех 5 моделей. Читает manifest.csv (ШАГ 1),
поэтому split гарантированно одинаков везде — требование воспроизводимости.

Используется в train.py (ШАГ 2), evaluate.py (ШАГ 3), demo (ШАГ 4).
"""
from __future__ import annotations
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


class ManifestDataset(Dataset):
    """Картинки одного сплита из manifest.csv. Возвращает (tensor, label, path)."""

    def __init__(self, manifest_csv, split: str, transform=None):
        df = pd.read_csv(manifest_csv)
        self.df = df[df["split"] == split].reset_index(drop=True)
        if len(self.df) == 0:
            raise ValueError(f"В manifest нет записей для split='{split}'")
        self.transform = transform
        self.paths = self.df["path"].tolist()
        self.labels = self.df["label_idx"].astype(int).tolist()
        self.classes = self.df["class"].tolist()

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        img = Image.open(self.paths[i]).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, self.labels[i], self.paths[i]


def build_transforms(split: str, image_size: int = 224,
                     mean=IMAGENET_MEAN, std=IMAGENET_STD):
    """Аугментации train vs детерминированный препроцессинг для val/test."""
    if split == "train":
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size, scale=(0.7, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomVerticalFlip(p=0.2),
            transforms.RandomRotation(20),
            transforms.ColorJitter(0.2, 0.2, 0.2, 0.05),
            transforms.ToTensor(),
            transforms.Normalize(mean, std),
        ])
    resize = int(round(image_size * 1.14))
    return transforms.Compose([
        transforms.Resize(resize),
        transforms.CenterCrop(image_size),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])


def get_norm_stats(norm_stats_json) -> tuple[list, list]:
    """Вернуть (mean, std) согласно configs/norm_stats.json (imagenet|dataset)."""
    with open(norm_stats_json, "r", encoding="utf-8") as f:
        d = json.load(f)
    key = d.get("used", "imagenet")
    src = d.get(key, d["imagenet"])
    return src["mean"], src["std"]


def get_class_weights(manifest_csv, num_classes: int) -> torch.Tensor:
    """Веса классов (inverse-frequency) на train — для борьбы с дисбалансом."""
    df = pd.read_csv(manifest_csv)
    counts = df[df["split"] == "train"]["label_idx"].value_counts().sort_index()
    counts = counts.reindex(range(num_classes), fill_value=0).to_numpy()
    w = counts.sum() / (num_classes * np.clip(counts, 1, None))
    return torch.tensor(w, dtype=torch.float32)


def build_dataloaders(manifest_csv, image_size, mean, std,
                      batch_size=32, num_workers=2, device_type="mps"):
    """train/val/test DataLoader'ы. pin_memory только для CUDA (на MPS бесполезен)."""
    pin = device_type == "cuda"
    loaders = {}
    for split in ("train", "val", "test"):
        ds = ManifestDataset(
            manifest_csv, split,
            build_transforms(split, image_size, mean, std))
        loaders[split] = DataLoader(
            ds, batch_size=batch_size, shuffle=(split == "train"),
            num_workers=num_workers, pin_memory=pin,
            persistent_workers=(num_workers > 0), drop_last=False)
    return loaders
