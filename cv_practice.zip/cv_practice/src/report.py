"""
ШАГ 5 — Отчётность.

  • Сохраняет историю запусков в SQLite (runs/history.db).
  • Генерирует Excel (report/report.xlsx): сравнение + по-классовые метрики.
  • Генерирует PDF (report/report.pdf): постановка задачи, данные, таблица сравнения,
    confusion matrix лучшей модели, и ОБЯЗАТЕЛЬНО 3 удачных + 3 ошибочных примера.

Запуск (после ШАГА 3 evaluate):
  python -m src.report
"""
from __future__ import annotations
import argparse
import json
import sqlite3
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
from PIL import Image  # noqa: E402

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.utils.config import load_config, resolve_path  # noqa: E402

# reportlab + кириллица (DejaVuSans из matplotlib)
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # noqa: E402
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,  # noqa: E402
                                Spacer, Image as RLImage)
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402
import matplotlib.font_manager as fm  # noqa: E402


def _register_cyrillic_font() -> str:
    path = fm.findfont("DejaVu Sans")
    pdfmetrics.registerFont(TTFont("DejaVu", path))
    bold = fm.findfont("DejaVu Sans:bold")
    pdfmetrics.registerFont(TTFont("DejaVu-Bold", bold))
    return "DejaVu"


# ───────────────────────── история в SQLite ─────────────────────────────
def save_history_db(df: pd.DataFrame, db_path: Path):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db_path)
    ts = datetime.now().isoformat(timespec="seconds")
    df2 = df.copy()
    df2.insert(0, "run_time", ts)
    df2.to_sql("runs", con, if_exists="append", index=False)
    con.close()
    return ts


# ───────────────────────── примеры (3 удачных / 3 ошибочных) ─────────────
def make_examples_grid(pred_csv: Path, out_path: Path, correct: bool, n: int = 3):
    df = pd.read_csv(pred_csv)
    sub = df[df["correct"] == correct].copy()
    if sub.empty:
        return None
    if correct:
        # удачные: уверенные и разнообразные по классам
        sub = sub.sort_values("confidence", ascending=False)
        picked, seen = [], set()
        for _, r in sub.iterrows():
            if r["true"] not in seen:
                picked.append(r); seen.add(r["true"])
            if len(picked) == n:
                break
        while len(picked) < n and len(picked) < len(sub):
            picked.append(sub.iloc[len(picked)])
    else:
        # ошибочные: самые «уверенные» ошибки — наиболее информативны
        picked = [r for _, r in sub.sort_values("confidence", ascending=False).head(n).iterrows()]

    k = len(picked)
    fig, axes = plt.subplots(1, k, figsize=(4 * k, 4.4))
    if k == 1:
        axes = [axes]
    for ax, r in zip(axes, picked):
        try:
            ax.imshow(Image.open(r["path"]).convert("RGB"))
        except Exception:
            pass
        ax.axis("off")
        color = "green" if correct else "red"
        ax.set_title(f"истина: {r['true']}\nпредсказано: {r['pred']}\n"
                     f"уверенность: {r['confidence']:.0%}",
                     fontsize=10, color=color)
    fig.suptitle("Удачные примеры" if correct else "Ошибочные примеры",
                 fontsize=13, fontweight="bold")
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=130, bbox_inches="tight")
    plt.close(fig)
    return out_path


# ───────────────────────── Excel ────────────────────────────────────────
def export_excel(df: pd.DataFrame, eval_dir: Path, out_xlsx: Path, class_names):
    out_xlsx.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as xw:
        df.to_excel(xw, sheet_name="Сравнение", index=False)
        for key in df["model"]:
            mp = eval_dir / f"{key}_metrics.json"
            if not mp.exists():
                continue
            m = json.loads(mp.read_text())["test"]["per_class"]
            pc = pd.DataFrame(m).T.reset_index().rename(columns={"index": "class"})
            pc.to_excel(xw, sheet_name=key[:28], index=False)
    return out_xlsx


# ───────────────────────── Word (.docx) ─────────────────────────────────
def export_docx(df, best, stats, eval_dir, report_dir, out_docx, examples, task, note):
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(11)

    t = doc.add_heading(task.get("title", "Классификация изображений"), level=0)
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub = doc.add_paragraph(task.get("subtitle",
          "Сравнение 5 архитектур нейронных сетей • отчёт по практике"))
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading("1. Задача и данные", level=1)
    doc.add_paragraph(
        f"{task.get('description', '').strip()} "
        f"Классификация на {stats['num_classes']} классов "
        f"({', '.join(stats['classes'])}); всего {stats['total_images']} изображений "
        f"после очистки. Разбиение train/val/test = {stats['counts']['train']}/"
        f"{stats['counts']['val']}/{stats['counts']['test']}, seed={stats['seed']}. "
        f"Единый split для всех моделей, контроль утечки (md5 + perceptual hash), "
        f"дисбаланс классов компенсирован взвешенным CrossEntropy.")

    doc.add_heading("2. Сравнение архитектур (тест)", level=1)
    cols = ["model", "family", "params_M", "size_MB", "test_acc",
            "test_macro_f1", "test_precision", "test_recall", "fps"]
    cols = [c for c in cols if c in df.columns]
    head = ["Модель", "Семейство", "Пар., M", "Размер, МБ", "Accuracy",
            "macro-F1", "Precision", "Recall", "FPS"][:len(cols)]
    table = doc.add_table(rows=1, cols=len(cols))
    table.style = "Light Grid Accent 1"
    for j, h in enumerate(head):
        cell = table.rows[0].cells[j]
        cell.text = h
        for r in cell.paragraphs[0].runs:
            r.font.bold = True
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for j, c in enumerate(cols):
            cells[j].text = str(row[c])
    p = doc.add_paragraph()
    run = p.add_run(f"Рекомендуемая модель: {best}. {note}")
    run.bold = True
    run.font.color.rgb = RGBColor(0x2E, 0x7D, 0x32)

    cmp_img = report_dir / "model_comparison.png"
    if cmp_img.exists():
        doc.add_picture(str(cmp_img), width=Inches(6.2))

    cm_img = report_dir / f"confusion_{best}.png"
    if cm_img.exists():
        doc.add_heading(f"3. Confusion matrix лучшей модели ({best})", level=1)
        doc.add_picture(str(cm_img), width=Inches(5.6))

    doc.add_heading("4. Примеры работы модели", level=1)
    for img in examples:
        if img and Path(img).exists():
            doc.add_picture(str(img), width=Inches(6.4))

    mp = eval_dir / f"{best}_metrics.json"
    if mp.exists():
        tc = json.loads(mp.read_text()).get("top_confusions", [])[:5]
        if tc:
            doc.add_heading("5. Частые ошибки (что с чем путается)", level=1)
            for a, b, c in tc:
                doc.add_paragraph(f"{a} → {b}: {c} раз", style="List Bullet")
            doc.add_paragraph(
                "Похожие материалы путаются из-за схожей фактуры/прозрачности и бликов "
                "(например, стекло и металл, бумага и картон). Пути улучшения: больше "
                "данных по «слабым» классам, аккуратнее разметка, аугментации бликов, "
                "повышение порога уверенности с ручной перепроверкой.")

    out_docx.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_docx))
    return out_docx


# ───────────────────────── PDF ──────────────────────────────────────────
def export_pdf(df, best, stats, eval_dir, report_dir, out_pdf, examples, task, note):
    font = _register_cyrillic_font()
    styles = getSampleStyleSheet()
    for s in styles.byName.values():
        s.fontName = font
    h1 = ParagraphStyle("h1", parent=styles["Title"], fontName="DejaVu-Bold", fontSize=18)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontName="DejaVu-Bold", fontSize=13)
    body = styles["BodyText"]

    doc = SimpleDocTemplate(str(out_pdf), pagesize=A4,
                            leftMargin=1.5*cm, rightMargin=1.5*cm,
                            topMargin=1.5*cm, bottomMargin=1.5*cm)
    el = []
    el.append(Paragraph(task.get("title", "Классификация изображений"), h1))
    el.append(Paragraph(task.get("subtitle",
              "Сравнение 5 архитектур нейронных сетей • отчёт по практике"), body))
    el.append(Spacer(1, 0.4*cm))

    el.append(Paragraph("1. Задача и данные", h2))
    el.append(Paragraph(
        f"{task.get('description', '').strip()} "
        f"Классификация на {stats['num_classes']} классов, "
        f"всего {stats['total_images']} изображений после очистки. "
        f"Разбиение train/val/test = {stats['counts']['train']}/{stats['counts']['val']}/"
        f"{stats['counts']['test']}, seed={stats['seed']}, "
        f"единый split для всех моделей, контроль утечки (md5+pHash).", body))
    el.append(Spacer(1, 0.3*cm))

    el.append(Paragraph("2. Сравнение архитектур (test)", h2))
    cols = ["model", "family", "params_M", "size_MB", "test_acc",
            "test_macro_f1", "test_precision", "test_recall", "fps"]
    cols = [c for c in cols if c in df.columns]
    head = ["модель", "семейство", "пар.,M", "разм.,МБ", "acc",
            "macroF1", "prec", "recall", "FPS"][:len(cols)]
    data = [head] + [[str(r[c]) for c in cols] for _, r in df.iterrows()]
    t = Table(data, repeatRows=1)
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), font),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2e7d32")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#eef5ee")]),
    ]))
    el.append(t)
    el.append(Spacer(1, 0.2*cm))
    el.append(Paragraph(f"<b>Рекомендуемая модель: {best}.</b> {note}", body))
    el.append(Spacer(1, 0.3*cm))

    cmp_img = report_dir / "model_comparison.png"
    if cmp_img.exists():
        el.append(RLImage(str(cmp_img), width=14*cm, height=9.3*cm))
        el.append(Spacer(1, 0.3*cm))

    cm_img = report_dir / f"confusion_{best}.png"
    if cm_img.exists():
        el.append(Paragraph(f"3. Confusion matrix лучшей модели ({best})", h2))
        el.append(RLImage(str(cm_img), width=13*cm, height=11*cm))
        el.append(Spacer(1, 0.3*cm))

    el.append(Paragraph("4. Примеры работы модели", h2))
    for img in examples:
        if img and Path(img).exists():
            el.append(RLImage(str(img), width=15*cm, height=5.4*cm))
            el.append(Spacer(1, 0.2*cm))

    # топ-перепутывания лучшей модели
    mp = eval_dir / f"{best}_metrics.json"
    if mp.exists():
        tc = json.loads(mp.read_text()).get("top_confusions", [])[:5]
        if tc:
            el.append(Paragraph("5. Частые ошибки (что с чем путается)", h2))
            for a, b, c in tc:
                el.append(Paragraph(f"• {a} → {b}: {c} раз", body))
    doc.build(el)
    return out_pdf


def main():
    ap = argparse.ArgumentParser(description="Отчёт PDF/Excel + история (ШАГ 5)")
    ap.add_argument("--config", default="configs/train.yaml")
    args = ap.parse_args()
    cfg = load_config(args.config)
    data_cfg = load_config(cfg["data_config"])
    runs = resolve_path(cfg["runs_dir"])
    eval_dir = runs / "eval"
    report_dir = resolve_path("report")

    comp = runs / "comparison.csv"
    if not comp.exists():
        raise SystemExit("Нет runs/comparison.csv — сначала запусти ШАГ 3 (evaluate).")
    df = pd.read_csv(comp)
    stats = json.loads((resolve_path(data_cfg["stats_json"])).read_text())
    class_names = json.loads(resolve_path(data_cfg["class_map_json"]).read_text())["classes"]

    # Лучшая по валидации vs по тесту. Для прототипа рекомендуем по совокупности
    # качества на тесте и скорости (практическая применимость — требование методички).
    best_val = df.sort_values("val_macro_f1", ascending=False).iloc[0]
    best_test = df.sort_values("test_macro_f1", ascending=False).iloc[0]
    best = best_test["model"]
    note = (f"По валидации лучшей оказалась {best_val['model']} "
            f"(val macro-F1={best_val['val_macro_f1']}). На независимом тесте лучшие "
            f"качество и скорость у {best}: test macro-F1={best_test['test_macro_f1']}, "
            f"{best_test['fps']} FPS, {best_test['size_MB']} МБ — её и рекомендуем "
            f"для прототипа сортировки.")
    (runs / "best_model.json").write_text(json.dumps(
        {"recommended_model": best, "best_by_val": best_val["model"],
         "best_by_test": best_test["model"], "note": note,
         "checkpoint": str(resolve_path(cfg["out_models_dir"]) / f"{best}.pt")},
        ensure_ascii=False, indent=2), encoding="utf-8")

    # 1) история в SQLite
    ts = save_history_db(df, runs / "history.db")
    print(f"История записана в runs/history.db (run_time={ts})")

    # 2) примеры 3 удачных / 3 ошибочных по лучшей модели
    pred_csv = eval_dir / f"{best}_predictions.csv"
    ex_ok = make_examples_grid(pred_csv, report_dir / "examples_success.png", True, 3)
    ex_err = make_examples_grid(pred_csv, report_dir / "examples_errors.png", False, 3)
    print(f"Примеры: {ex_ok}, {ex_err}")

    task = data_cfg.get("task", {})

    # 3) Excel
    xlsx = export_excel(df, eval_dir, report_dir / "report.xlsx", class_names)
    print(f"Excel: {xlsx}")

    # 4) Word (.docx)
    docx_path = export_docx(df, best, stats, eval_dir, report_dir,
                            report_dir / "report.docx", [ex_ok, ex_err], task, note)
    print(f"DOCX: {docx_path}")

    # 5) PDF
    pdf = export_pdf(df, best, stats, eval_dir, report_dir,
                     report_dir / "report.pdf", [ex_ok, ex_err], task, note)
    print(f"PDF: {pdf}")
    print("\nГотово. Отчёты в report/.")


if __name__ == "__main__":
    main()
