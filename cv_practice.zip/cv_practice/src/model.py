"""Фабрика моделей поверх timm + утилиты размера/чекпоинтов.

Один и тот же интерфейс для всех 5 архитектур — это гарантирует, что
сравнение честное (различается только сама сеть, а не обвязка).
"""
from __future__ import annotations
import json
from pathlib import Path

import timm
import torch


def build_model(timm_id: str, num_classes: int, pretrained: bool = True):
    """Создать модель с зам'ененной классификационной головой на num_classes."""
    return timm.create_model(timm_id, pretrained=pretrained, num_classes=num_classes)


def count_parameters(model, trainable_only: bool = False) -> int:
    return sum(p.numel() for p in model.parameters()
               if (p.requires_grad or not trainable_only))


def state_dict_size_mb(model) -> float:
    """Теоретический размер весов в МБ (параметры + буферы)."""
    n = sum(p.numel() * p.element_size() for p in model.parameters())
    n += sum(b.numel() * b.element_size() for b in model.buffers())
    return n / 1e6


def freeze_backbone(model, freeze: bool = True):
    """Заморозить всё, кроме классификационной головы (timm: get_classifier)."""
    for p in model.parameters():
        p.requires_grad = not freeze
    head = model.get_classifier()
    for p in head.parameters():
        p.requires_grad = True


def save_checkpoint(path, model, meta: dict):
    """Сохранить веса + метаданные (timm_id, классы, нормализация, метрики)."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": model.state_dict(), **meta}, path)


def load_checkpoint(path, device="cpu", pretrained=False):
    """Восстановить модель из чекпоинта (для evaluate.py / demo)."""
    ckpt = torch.load(path, map_location=device, weights_only=False)
    model = build_model(ckpt["timm_id"], ckpt["num_classes"], pretrained=pretrained)
    model.load_state_dict(ckpt["state_dict"])
    model.to(device).eval()
    return model, ckpt
