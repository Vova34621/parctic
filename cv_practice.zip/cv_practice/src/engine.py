"""Циклы обучения и инференса — общие для train.py (ШАГ 2) и evaluate.py (ШАГ 3)."""
from __future__ import annotations
import time

import numpy as np
import torch
from tqdm import tqdm


def train_one_epoch(model, loader, optimizer, criterion, device,
                    amp=False, desc="train"):
    model.train()
    running, n = 0.0, 0
    use_amp = amp and device.type in ("cuda", "mps")
    for imgs, labels, _ in tqdm(loader, desc=desc, leave=False):
        imgs = imgs.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        if use_amp:
            with torch.autocast(device_type=device.type, dtype=torch.float16):
                out = model(imgs)
                loss = criterion(out, labels)
        else:
            out = model(imgs)
            loss = criterion(out, labels)
        loss.backward()
        optimizer.step()
        running += loss.item() * imgs.size(0)
        n += imgs.size(0)
    return running / max(n, 1)


@torch.no_grad()
def evaluate_model(model, loader, criterion, device, desc="eval"):
    """Прогон по loader'у. Возвращает loss + массивы y_true/y_pred/y_prob/paths."""
    model.eval()
    running, n = 0.0, 0
    ys, ps, probs, paths = [], [], [], []
    for imgs, labels, pth in tqdm(loader, desc=desc, leave=False):
        imgs = imgs.to(device, non_blocking=True)
        labels_d = labels.to(device, non_blocking=True)
        out = model(imgs)
        if criterion is not None:
            running += criterion(out, labels_d).item() * imgs.size(0)
        n += imgs.size(0)
        prob = torch.softmax(out, dim=1).cpu().numpy()
        ys.append(labels.numpy())
        ps.append(prob.argmax(1))
        probs.append(prob)
        paths.extend(pth)
    return {
        "loss": running / max(n, 1),
        "y_true": np.concatenate(ys),
        "y_pred": np.concatenate(ps),
        "y_prob": np.concatenate(probs),
        "paths": paths,
    }


@torch.no_grad()
def measure_latency(model, device, image_size=224, warmup=5, runs=30, batch_size=1):
    """Среднее время инференса на 1 изображение (мс) и FPS — для таблицы сравнения."""
    model.eval()
    x = torch.randn(batch_size, 3, image_size, image_size, device=device)
    for _ in range(warmup):
        model(x)
    if device.type == "mps":
        torch.mps.synchronize()
    elif device.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(runs):
        model(x)
    if device.type == "mps":
        torch.mps.synchronize()
    elif device.type == "cuda":
        torch.cuda.synchronize()
    dt = (time.perf_counter() - t0) / runs
    ms_per_img = dt / batch_size * 1000
    return {"ms_per_image": ms_per_img, "fps": 1000.0 / ms_per_img,
            "batch_size": batch_size, "device": device.type}
