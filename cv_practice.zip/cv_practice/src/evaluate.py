"""
ШАГ 3 — Финальная оценка моделей на TEST (один раз!) + сравнительная таблица.

Для каждой обученной модели считает (методичка, разд. 7):
  accuracy, precision/recall/F1 (macro и weighted), confusion matrix,
  среднее время инференса (мс/изобр.) и FPS, размер модели (МБ), число параметров.

Лучшую модель выбираем по VAL macro-F1 (test НЕ подбираем) — пишем runs/best_model.json.

Выход:
  runs/eval/<key>_metrics.json
  runs/eval/<key>_predictions.csv         (path,true,pred,correct,conf — для ШАГ 5)
  report/confusion_<key>.png
  runs/comparison.csv  + красивая таблица в консоли
  report/model_comparison.png

Запуск:
  python -m src.evaluate                 # все модели из models/
  python -m src.evaluate --device mps
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

import pandas as pd
import torch
import torch.nn as nn

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.utils.config import load_config, resolve_path, PROJECT_ROOT
from src.utils.seed import seed_everything
from src.utils.device import get_device
from src.utils.metrics import classification_metrics, top_confusions
from src.utils.plots import plot_confusion_matrix, plot_model_comparison
from src.data.dataset import ManifestDataset, build_transforms, get_norm_stats
from src.model import load_checkpoint
from src.engine import evaluate_model, measure_latency
from torch.utils.data import DataLoader


def make_test_loader(manifest, image_size, mean, std, batch_size, num_workers, dev_type):
    ds = ManifestDataset(manifest, "test", build_transforms("test", image_size, mean, std))
    return DataLoader(ds, batch_size=batch_size, shuffle=False,
                      num_workers=num_workers, pin_memory=(dev_type == "cuda"))


def main():
    ap = argparse.ArgumentParser(description="Оценка на test (ШАГ 3)")
    ap.add_argument("--config", default="configs/train.yaml")
    ap.add_argument("--models", nargs="*", default=None, help="ключи; по умолчанию все из models/")
    ap.add_argument("--device", default=None)
    ap.add_argument("--batch-size", type=int, default=64)
    args = ap.parse_args()

    cfg = load_config(args.config)
    data_cfg = load_config(cfg["data_config"])
    seed_everything(cfg["seed"])
    device = get_device(args.device or cfg["device"])
    print(f"Устройство: {device}")

    manifest = str(resolve_path(data_cfg["manifest_csv"]))
    mean, std = get_norm_stats(resolve_path(data_cfg["norm_stats_json"]))
    with open(resolve_path(data_cfg["class_map_json"]), encoding="utf-8") as f:
        class_names = json.load(f)["classes"]

    models_dir = resolve_path(cfg["out_models_dir"])
    keys = args.models or [p.stem for p in sorted(models_dir.glob("*.pt"))]
    if not keys:
        raise SystemExit("Нет обученных моделей в models/. Сначала ШАГ 2 (train).")

    eval_dir = resolve_path(cfg["runs_dir"]) / "eval"
    eval_dir.mkdir(parents=True, exist_ok=True)
    report_dir = resolve_path("report")

    test_loader = make_test_loader(manifest, cfg["image_size"], mean, std,
                                   args.batch_size, cfg["num_workers"], device.type)
    print(f"Test-изображений: {len(test_loader.dataset)} | классов: {len(class_names)}\n")

    # val-метрики из обучения (для честного выбора лучшей модели)
    train_summary = {}
    ts_path = resolve_path(cfg["runs_dir"]) / "train_summary.csv"
    if ts_path.exists():
        train_summary = pd.read_csv(ts_path).set_index("model").to_dict("index")

    rows = []
    for key in keys:
        ckpt_path = models_dir / f"{key}.pt"
        print(f"── {key} ──")
        model, ckpt = load_checkpoint(ckpt_path, device=device)
        out = evaluate_model(model, test_loader, nn.CrossEntropyLoss(), device, desc=f"{key} test")
        m = classification_metrics(out["y_true"], out["y_pred"], class_names)
        lat = measure_latency(model, device, image_size=cfg["image_size"])
        size_mb = ckpt_path.stat().st_size / 1e6

        # сохранить предсказания (для подбора примеров в ШАГ 5)
        conf = out["y_prob"].max(1)
        pred_df = pd.DataFrame({
            "path": out["paths"],
            "true": [class_names[i] for i in out["y_true"]],
            "pred": [class_names[i] for i in out["y_pred"]],
            "correct": out["y_true"] == out["y_pred"],
            "confidence": conf,
        })
        pred_df.to_csv(eval_dir / f"{key}_predictions.csv", index=False)

        plot_confusion_matrix(
            m["confusion_matrix"], class_names,
            report_dir / f"confusion_{key}.png",
            title=f"Confusion matrix — {key} (test)", normalize=True)

        with open(eval_dir / f"{key}_metrics.json", "w", encoding="utf-8") as f:
            json.dump({"key": key, "family": ckpt.get("family"),
                       "test": m, "latency": lat, "size_MB": size_mb,
                       "n_params": ckpt.get("n_params"),
                       "top_confusions": top_confusions(m["confusion_matrix"], class_names)},
                      f, ensure_ascii=False, indent=2)

        vs = train_summary.get(key, {})
        rows.append({
            "model": key, "family": ckpt.get("family", ""),
            "input": f"{cfg['image_size']}x{cfg['image_size']}",
            "params_M": round((ckpt.get("n_params") or 0) / 1e6, 2),
            "size_MB": round(size_mb, 1),
            "val_macro_f1": vs.get("best_val_macro_f1"),
            "test_acc": round(m["accuracy"], 4),
            "test_macro_f1": round(m["macro_f1"], 4),
            "test_precision": round(m["macro_precision"], 4),
            "test_recall": round(m["macro_recall"], 4),
            "ms_per_image": round(lat["ms_per_image"], 2),
            "fps": round(lat["fps"], 1),
        })
        print(f"   test_acc={m['accuracy']:.4f} test_macroF1={m['macro_f1']:.4f} "
              f"| {lat['fps']:.1f} FPS | {size_mb:.1f} МБ")

    df = pd.DataFrame(rows)
    # лучшая модель — по VAL (если есть), иначе по test
    sort_key = "val_macro_f1" if df["val_macro_f1"].notna().any() else "test_macro_f1"
    df = df.sort_values(sort_key, ascending=False).reset_index(drop=True)
    best = df.iloc[0]["model"]

    comp_path = resolve_path(cfg["runs_dir"]) / "comparison.csv"
    df.to_csv(comp_path, index=False)
    plot_model_comparison(df, report_dir / "model_comparison.png")
    with open(resolve_path(cfg["runs_dir"]) / "best_model.json", "w", encoding="utf-8") as f:
        json.dump({"best_model": best, "selected_by": sort_key,
                   "checkpoint": str((models_dir / f"{best}.pt"))}, f,
                  ensure_ascii=False, indent=2)

    print(f"\n{'='*72}\n  СРАВНИТЕЛЬНАЯ ТАБЛИЦА (test) — {comp_path.relative_to(PROJECT_ROOT)}\n{'='*72}")
    print(df.to_string(index=False))
    print(f"\nЛучшая модель (по {sort_key}): >>> {best} <<<  → для демо (ШАГ 4)")


if __name__ == "__main__":
    main()
