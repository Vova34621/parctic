"""
ШАГ 4 — Переиспользуемый предиктор. Грузит чекпоинт и предсказывает по одному изображению.
Используется в demo/app.py и в отчёте (ШАГ 5).
"""
from __future__ import annotations
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.utils.device import get_device
from src.data.dataset import build_transforms
from src.model import load_checkpoint


class Predictor:
    """Обёртка над обученной моделью: PIL-изображение -> топ-k классов + уверенность + время."""

    def __init__(self, ckpt_path, device: str | None = None):
        self.device = get_device(device or "auto")
        self.model, self.ckpt = load_checkpoint(ckpt_path, device=self.device)
        self.classes = self.ckpt["classes"]
        self.image_size = self.ckpt["image_size"]
        self.transform = build_transforms(
            "test", self.image_size, self.ckpt["norm_mean"], self.ckpt["norm_std"])
        self.key = self.ckpt.get("key", Path(ckpt_path).stem)

    @torch.no_grad()
    def predict(self, image: Image.Image, topk: int = 5) -> dict:
        x = self.transform(image.convert("RGB")).unsqueeze(0).to(self.device)
        t0 = time.perf_counter()
        logits = self.model(x)
        if self.device.type == "mps":
            torch.mps.synchronize()
        elif self.device.type == "cuda":
            torch.cuda.synchronize()
        ms = (time.perf_counter() - t0) * 1000
        probs = torch.softmax(logits, dim=1)[0].cpu().numpy()
        order = np.argsort(probs)[::-1][:topk]
        return {
            "label": self.classes[int(order[0])],
            "confidence": float(probs[int(order[0])]),
            "topk": [(self.classes[int(i)], float(probs[int(i)])) for i in order],
            "probs": {self.classes[i]: float(probs[i]) for i in range(len(self.classes))},
            "inference_ms": ms,
            "model": self.key,
        }
