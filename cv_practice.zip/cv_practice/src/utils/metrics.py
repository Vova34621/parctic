"""Метрики классификации (методичка, разд. 7): accuracy, precision, recall, F1, confusion matrix."""
from __future__ import annotations
import numpy as np
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                             confusion_matrix)


def classification_metrics(y_true, y_pred, class_names) -> dict:
    """Полный набор метрик для отчёта. macro — честно при дисбалансе классов."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    n = len(class_names)
    labels = list(range(n))

    acc = accuracy_score(y_true, y_pred)
    p_mac, r_mac, f_mac, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="macro", zero_division=0)
    p_wt, r_wt, f_wt, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="weighted", zero_division=0)
    p_c, r_c, f_c, sup = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average=None, zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=labels)

    per_class = {
        class_names[i]: {
            "precision": float(p_c[i]), "recall": float(r_c[i]),
            "f1": float(f_c[i]), "support": int(sup[i]),
        } for i in range(n)
    }
    return {
        "accuracy": float(acc),
        "macro_precision": float(p_mac), "macro_recall": float(r_mac),
        "macro_f1": float(f_mac),
        "weighted_precision": float(p_wt), "weighted_recall": float(r_wt),
        "weighted_f1": float(f_wt),
        "per_class": per_class,
        "confusion_matrix": cm.tolist(),
    }


def top_confusions(cm, class_names, k: int = 5):
    """k самых частых перепутываний (off-diagonal) — для анализа ошибок."""
    cm = np.asarray(cm)
    pairs = []
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            if i != j and cm[i, j] > 0:
                pairs.append((class_names[i], class_names[j], int(cm[i, j])))
    pairs.sort(key=lambda x: -x[2])
    return pairs[:k]
