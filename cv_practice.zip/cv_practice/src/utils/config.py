"""Загрузка YAML-конфига и разрешение относительных путей от корня проекта."""
from __future__ import annotations
from pathlib import Path

import yaml

# .../cv_practice/  (поднимаемся: utils -> src -> cv_practice)
PROJECT_ROOT = Path(__file__).resolve().parents[2]


def load_config(path: str | Path) -> dict:
    path = Path(path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def resolve_path(p: str | Path) -> Path:
    """Относительный путь -> абсолютный (от корня проекта)."""
    p = Path(p)
    return p if p.is_absolute() else (PROJECT_ROOT / p)
