"""Выбор устройства с приоритетом MPS (Apple Silicon)."""
from __future__ import annotations
import os


def get_device(prefer: str = "auto"):
    """Вернуть torch.device. prefer: auto | mps | cuda | cpu.

    Для MPS включаем PYTORCH_ENABLE_MPS_FALLBACK=1 — часть операций
    ещё не реализована на MPS, и без фолбэка обучение упадёт.
    """
    import torch

    if prefer not in ("auto", "mps", "cuda", "cpu"):
        prefer = "auto"

    if prefer == "cpu":
        return torch.device("cpu")

    if prefer in ("auto", "mps") and torch.backends.mps.is_available():
        os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
        return torch.device("mps")

    if prefer in ("auto", "cuda") and torch.cuda.is_available():
        return torch.device("cuda")

    return torch.device("cpu")


def device_type(device) -> str:
    return device.type if hasattr(device, "type") else str(device)
