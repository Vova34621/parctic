"""Графики для отчёта: confusion matrix, кривые обучения, сравнение моделей."""
from __future__ import annotations
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import seaborn as sns  # noqa: E402


def plot_confusion_matrix(cm, class_names, path, title="Confusion matrix",
                          normalize=True):
    cm = np.asarray(cm, dtype=float)
    if normalize:
        row = cm.sum(axis=1, keepdims=True)
        cm_n = np.divide(cm, row, out=np.zeros_like(cm), where=row > 0)
        data, fmt = cm_n, ".2f"
    else:
        data, fmt = cm, ".0f"
    fig, ax = plt.subplots(figsize=(max(7, len(class_names) * 0.9),
                                    max(6, len(class_names) * 0.8)))
    sns.heatmap(data, annot=True, fmt=fmt, cmap="Blues", cbar=True,
                xticklabels=class_names, yticklabels=class_names, ax=ax,
                vmin=0, vmax=1 if normalize else None)
    ax.set_xlabel("Предсказано")
    ax.set_ylabel("Истинный класс")
    ax.set_title(title)
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(path, dpi=130)
    plt.close(fig)


def plot_training_curves(history, path, title="Кривые обучения"):
    ep = [h["epoch"] for h in history]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.5))
    a1.plot(ep, [h["train_loss"] for h in history], "-o", label="train_loss")
    a1.plot(ep, [h["val_loss"] for h in history], "-o", label="val_loss")
    a1.set_xlabel("эпоха"); a1.set_ylabel("loss"); a1.legend(); a1.grid(alpha=.3)
    a2.plot(ep, [h["val_acc"] for h in history], "-o", label="val_acc")
    a2.plot(ep, [h["val_macro_f1"] for h in history], "-o", label="val_macroF1")
    a2.set_xlabel("эпоха"); a2.set_ylabel("метрика"); a2.legend(); a2.grid(alpha=.3)
    fig.suptitle(title)
    plt.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(path, dpi=130)
    plt.close(fig)


def plot_model_comparison(df, path, metric="test_macro_f1"):
    """Сравнение: качество vs скорость vs размер (пузырьковая диаграмма)."""
    fig, ax = plt.subplots(figsize=(9, 6))
    sizes = (df["size_MB"].to_numpy() / df["size_MB"].max()) * 1200 + 80
    sc = ax.scatter(df["fps"], df[metric], s=sizes, alpha=0.6,
                    c=range(len(df)), cmap="viridis")
    for _, r in df.iterrows():
        ax.annotate(r["model"], (r["fps"], r[metric]),
                    fontsize=9, ha="center", va="bottom")
    ax.set_xlabel("FPS (выше — быстрее)")
    ax.set_ylabel(metric)
    ax.set_title("Качество vs скорость (размер пузыря ∝ размер модели)")
    ax.grid(alpha=.3)
    plt.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(path, dpi=130)
    plt.close(fig)
