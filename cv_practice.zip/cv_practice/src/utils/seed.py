"""Фиксация всех источников случайности — требование воспроизводимости (методичка, разд. 6)."""
from __future__ import annotations
import os
import random

import numpy as np


def seed_everything(seed: int = 42) -> int:
    """Зафиксировать seed для random / numpy / torch (CPU, CUDA, MPS).

    MPS использует глобальный torch seed, отдельного API у него нет.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        # детерминизм по возможности; warn_only — чтобы не падать на MPS-операциях
        try:
            torch.use_deterministic_algorithms(True, warn_only=True)
        except Exception:
            pass
    except ImportError:
        pass
    return seed
