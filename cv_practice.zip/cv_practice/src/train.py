"""
ШАГ 2 — Обучение (дообучение) 5 архитектур в ОДИНАКОВЫХ условиях.

Честное сравнение (методичка, разд. 6): один manifest/split, один seed,
одинаковые epochs/optimizer/lr/augmentations/input size для всех моделей.
Отличается только сама архитектура.

Для каждой модели сохраняется:
  models/<key>.pt            — лучшие веса (по val macro-F1) + метаданные
  runs/<key>/history.json    — кривая обучения по эпохам
  runs/train_summary.csv     — строка со сводкой (для таблицы сравнения)

Запуск:
  python -m src.train --all                     # все 5 моделей подряд
  python -m src.train --model resnet50          # одна модель
  python -m src.train --all --epochs 8 --batch-size 32
"""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path

import pandas as pd
import torch
import torch.nn as nn

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.utils.config import load_config, resolve_path, PROJECT_ROOT
from src.utils.seed import seed_everything
from src.utils.device import get_device
from src.utils.metrics import classification_metrics
from src.data.dataset import build_dataloaders, get_norm_stats, get_class_weights
from src.model import (build_model, count_parameters, state_dict_size_mb,
                       freeze_backbone, save_checkpoint)
from src.engine import train_one_epoch, evaluate_model


def build_optimizer(model, cfg):
    params = [p for p in model.parameters() if p.requires_grad]
    return torch.optim.AdamW(params, lr=cfg["lr"], weight_decay=cfg["weight_decay"])


def build_scheduler(optimizer, cfg):
    if cfg["scheduler"] != "cosine":
        return None
    warm = max(cfg.get("warmup_epochs", 0), 0)
    epochs = cfg["epochs"]
    if warm > 0:
        s1 = torch.optim.lr_scheduler.LinearLR(
            optimizer, start_factor=0.1, total_iters=warm)
        s2 = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(epochs - warm, 1))
        return torch.optim.lr_scheduler.SequentialLR(
            optimizer, [s1, s2], milestones=[warm])
    return torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)


def train_one_model(key, spec, cfg, loaders, class_names, device, norm):
    n_classes = len(class_names)
    print(f"\n{'='*64}\n  Модель: {key}  ({spec['family']})\n  timm_id: {spec['timm_id']}\n{'='*64}")

    model = build_model(spec["timm_id"], n_classes, pretrained=cfg["pretrained"]).to(device)
    n_params = count_parameters(model)
    size_mb = state_dict_size_mb(model)
    print(f"Параметров: {n_params/1e6:.2f}M | размер весов ≈ {size_mb:.1f} МБ")

    criterion = nn.CrossEntropyLoss(
        weight=(get_class_weights(cfg["_manifest"], n_classes).to(device)
                if cfg["class_weights"] else None),
        label_smoothing=cfg["label_smoothing"])

    freeze_n = cfg.get("freeze_epochs", 0)
    if freeze_n > 0:
        freeze_backbone(model, True)
    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg)

    run_dir = resolve_path(cfg["runs_dir"]) / key
    run_dir.mkdir(parents=True, exist_ok=True)
    ckpt_path = resolve_path(cfg["out_models_dir"]) / f"{key}.pt"

    history, best_f1, best_epoch, since_improve = [], -1.0, -1, 0
    t_start = time.perf_counter()

    for epoch in range(1, cfg["epochs"] + 1):
        if freeze_n > 0 and epoch == freeze_n + 1:
            print("  >> размораживаю backbone")
            freeze_backbone(model, False)
            optimizer = build_optimizer(model, cfg)
            scheduler = build_scheduler(optimizer, cfg)

        tr_loss = train_one_epoch(model, loaders["train"], optimizer, criterion,
                                  device, amp=cfg["amp"], desc=f"{key} e{epoch} train")
        val = evaluate_model(model, loaders["val"], criterion, device,
                             desc=f"{key} e{epoch} val")
        m = classification_metrics(val["y_true"], val["y_pred"], class_names)
        if scheduler is not None:
            scheduler.step()
        lr_now = optimizer.param_groups[0]["lr"]

        row = {"epoch": epoch, "train_loss": tr_loss, "val_loss": val["loss"],
               "val_acc": m["accuracy"], "val_macro_f1": m["macro_f1"], "lr": lr_now}
        history.append(row)
        print(f"  e{epoch:02d} | train_loss {tr_loss:.4f} | val_loss {val['loss']:.4f} "
              f"| val_acc {m['accuracy']:.4f} | val_macroF1 {m['macro_f1']:.4f}")

        improved = m[cfg["monitor"] if cfg["monitor"] in m else "macro_f1"] > best_f1
        if improved:
            best_f1 = m["macro_f1"]; best_epoch = epoch; since_improve = 0
            save_checkpoint(ckpt_path, model, {
                "key": key, "timm_id": spec["timm_id"], "family": spec["family"],
                "num_classes": n_classes, "classes": class_names,
                "image_size": cfg["image_size"],
                "norm_mean": norm[0], "norm_std": norm[1],
                "val_metrics": m, "epoch": epoch, "n_params": n_params,
            })
        else:
            since_improve += 1
            if since_improve >= cfg["early_stop_patience"]:
                print(f"  ранняя остановка (нет улучшения {since_improve} эпох)")
                break

    train_time = time.perf_counter() - t_start
    with open(run_dir / "history.json", "w", encoding="utf-8") as f:
        json.dump({"key": key, "history": history,
                   "best_epoch": best_epoch, "best_val_macro_f1": best_f1,
                   "train_time_sec": train_time}, f, ensure_ascii=False, indent=2)

    ckpt_mb = ckpt_path.stat().st_size / 1e6 if ckpt_path.exists() else size_mb
    print(f"  Готово: best val macroF1={best_f1:.4f} (эпоха {best_epoch}), "
          f"время {train_time/60:.1f} мин, чекпоинт {ckpt_mb:.1f} МБ")

    return {"model": key, "family": spec["family"], "timm_id": spec["timm_id"],
            "params_M": round(n_params / 1e6, 2), "size_MB": round(ckpt_mb, 1),
            "best_epoch": best_epoch, "best_val_macro_f1": round(best_f1, 4),
            "train_time_min": round(train_time / 60, 2),
            "epochs_run": len(history)}


def main():
    ap = argparse.ArgumentParser(description="Обучение 5 архитектур (ШАГ 2)")
    ap.add_argument("--config", default="configs/train.yaml")
    ap.add_argument("--model", default=None, help="ключ одной модели из models.yaml")
    ap.add_argument("--all", action="store_true", help="обучить все модели подряд")
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--device", default=None)
    ap.add_argument("--amp", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    data_cfg = load_config(cfg["data_config"])
    models_cfg = load_config(cfg["models_config"])["models"]
    if args.epochs: cfg["epochs"] = args.epochs
    if args.batch_size: cfg["batch_size"] = args.batch_size
    if args.device: cfg["device"] = args.device
    if args.amp: cfg["amp"] = True

    seed_everything(cfg["seed"])
    device = get_device(cfg["device"])
    print(f"Устройство: {device}")

    manifest = resolve_path(data_cfg["manifest_csv"])
    if not manifest.exists():
        raise SystemExit("Нет manifest.csv — сначала запусти ШАГ 1 (prepare_data).")
    cfg["_manifest"] = str(manifest)
    with open(resolve_path(data_cfg["class_map_json"]), encoding="utf-8") as f:
        class_names = json.load(f)["classes"]
    norm = get_norm_stats(resolve_path(data_cfg["norm_stats_json"]))

    loaders = build_dataloaders(
        str(manifest), cfg["image_size"], norm[0], norm[1],
        batch_size=cfg["batch_size"], num_workers=cfg["num_workers"],
        device_type=device.type)
    print(f"Данных: train={len(loaders['train'].dataset)} "
          f"val={len(loaders['val'].dataset)} test={len(loaders['test'].dataset)} "
          f"| классов={len(class_names)}")

    if args.all:
        keys = list(models_cfg.keys())
    elif args.model:
        if args.model not in models_cfg:
            raise SystemExit(f"Нет модели '{args.model}'. Доступны: {list(models_cfg)}")
        keys = [args.model]
    else:
        raise SystemExit("Укажи --all или --model <key>")

    summaries = []
    for key in keys:
        try:
            summaries.append(train_one_model(
                key, models_cfg[key], cfg, loaders, class_names, device, norm))
        except Exception as e:
            import traceback
            print(f"\n[!] Модель '{key}' упала: {type(e).__name__}: {e}")
            traceback.print_exc()
            print("    Пропускаю и продолжаю со следующей.\n")
    if not summaries:
        raise SystemExit("Ни одна модель не обучилась.")

    # сводка обучения (валидация!) — общий CSV
    summ_path = resolve_path(cfg["runs_dir"]) / "train_summary.csv"
    df = pd.DataFrame(summaries)
    if summ_path.exists():
        old = pd.read_csv(summ_path)
        df = pd.concat([old[~old["model"].isin(df["model"])], df], ignore_index=True)
    df.sort_values("best_val_macro_f1", ascending=False).to_csv(summ_path, index=False)
    print(f"\n{'='*64}\n  Сводка обучения (по VAL): {summ_path.relative_to(PROJECT_ROOT)}\n{'='*64}")
    print(df.sort_values("best_val_macro_f1", ascending=False).to_string(index=False))
    print("\nФинальная оценка на TEST — отдельно, в src/evaluate.py (ШАГ 3).")


if __name__ == "__main__":
    main()
