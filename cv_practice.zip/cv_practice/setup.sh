#!/usr/bin/env bash
# Создание изолированного окружения и установка зависимостей.
# Запуск:  bash setup.sh
set -e
cd "$(dirname "$0")"

PY=python3
echo ">> Python: $($PY --version)"

if [ ! -d ".venv" ]; then
  echo ">> Создаю виртуальное окружение .venv"
  $PY -m venv .venv
fi

# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip wheel
echo ">> Устанавливаю зависимости (torch может качаться несколько минут)…"
pip install -r requirements.txt

echo ""
echo ">> Готово. Активируй окружение командой:"
echo "     source .venv/bin/activate"
echo ">> Проверка MPS:"
python -c "import torch; print('MPS available:', torch.backends.mps.is_available())"
